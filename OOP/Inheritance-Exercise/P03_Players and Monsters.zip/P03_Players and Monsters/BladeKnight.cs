﻿namespace PlayersAndMonsters
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class BladeKnight : DarkKnight
    {
        public BladeKnight(string name, int level)
           : base(name, level)
        {

        }
    }
}
