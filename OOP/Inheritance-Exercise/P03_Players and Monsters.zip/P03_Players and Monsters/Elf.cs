﻿namespace PlayersAndMonsters
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Elf : Hero
    {
        public Elf(string name, int level)
          : base(name, level)
        {

        }
    }
}
