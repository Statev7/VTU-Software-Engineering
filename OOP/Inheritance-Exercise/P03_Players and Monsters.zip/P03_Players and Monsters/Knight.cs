﻿namespace PlayersAndMonsters
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Knight : Hero
    {
        public Knight(string name, int level)
            : base(name, level)
        {

        }
    }
}
