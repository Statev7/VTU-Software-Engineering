﻿namespace PlayersAndMonsters
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class MuseElf : Elf
    {
        public MuseElf(string name, int level)
         : base(name, level)
        {

        }
    }
}
